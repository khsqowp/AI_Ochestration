정찰/취약점 스캐너 올인원 오프라인 패키지 (내부망용)
======================================================

인터넷이 전혀 안 되고 이 웹사이트조차 못 여는 내부망 PC에 그대로 반입해서
쓰는 패키지. 3개 도구(.py 스크립트 + 설명서) + 그 도구들이 --tech/
--traversal/--wordlist에 쓰는 SecLists·PayloadsAllTheThings 서브셋
워드리스트까지 전부 한 번에 들어있다. 압축만 풀면 바로 실행 가능 --
pip install 같은 패키지 설치 전혀 필요 없음(전부 Python 표준 라이브러리만
사용).

각 폴더의 MANUAL_KR.txt가 원래 이름 "설명서.txt"다 -- zip 포맷은 한글
파일명을 옛날 방식(UTF-8 플래그 없이)으로 저장하면 Windows 압축 해제
프로그램에서 깨진 문자로 나오는 경우가 있어서, 이 zip 안에서만 영문
이름으로 바꿔둠. 내용은 그대로 한글 설명서다.

폴더 그대로 유지할 것 (스크립트가 자기 위치 기준 상대경로로 워드리스트를
찾음):
  default-content-scanner/default_content_scanner.py
  site-crawler/crawler.py
  safe-http-audit/safe_http_audit.py (+ safe_rule_bundle.py, safe_http_checks/)
  SecLists-master/                    <- 콘텐츠 스캐너·크롤러가 자동으로 찾음
  PayloadsAllTheThings-master/        <- 콘텐츠 스캐너가 자동으로 찾음

실행 방법
--------
각 폴더 안에서:
  python default_content_scanner.py          (인자 없이 실행 -> 한글 질문 순서대로)
  python crawler.py
  python safe_http_audit.py
자세한 옵션은 각 폴더의 MANUAL_KR.txt 참고. 인자 없이 실행한 뒤 마지막에
"고급 옵션을 더 조정할까요?"에 y로 답하면 옵션 번호 메뉴가 뜨는데, 이
메뉴 설명도 전부 한글로 나온다.

콘텐츠 스캐너 --tech에 nextjs도 추가됨(SecLists 파일 없이 내장 경로
목록 사용 -- _next/static/*, .next/BUILD_ID 등). 크롤러 --wordlist는
여러 번 줘서 여러 목록을 합쳐 쓸 수 있음(예: --wordlist common.txt
--wordlist raft-small-words.txt).

워드리스트 커버리지
------------------
콘텐츠 스캐너 --tech 6종(tomcat/apache/nginx/iis/jboss/db-backups)과
--traversal 페이로드 3개 파일은 코드가 쓰는 파일 전부 포함(빠진 것 없음).
nextjs는 SecLists 파일이 아니라 코드에 내장된 목록이라 별도 파일 불필요.
크롤러 --wordlist는 예시용 common.txt 하나만 포함 -- 다른 이름 쓰려면
원본 저장소에서 해당 파일만 SecLists-master/Discovery/Web-Content/ 안에
추가로 넣으면 됨. safe_http_audit은 외부 워드리스트를 아예 안 씀(자체
룰 파일만 사용, 이미 포함됨).

출처 / 라이선스: SecLists·PayloadsAllTheThings 둘 다 MIT 라이선스,
각 폴더의 LICENSE 파일 그대로 포함함.
  https://github.com/danielmiessler/SecLists
  https://github.com/swisskyrepo/PayloadsAllTheThings

주의
----
소유하거나 명시적으로 허가받은 대상에서만 사용할 것.
