정찰/취약점 스캐너 올인원 오프라인 패키지 (내부망용)
======================================================

인터넷이 전혀 안 되고 이 웹사이트조차 못 여는 내부망 PC에 그대로 반입해서
쓰는 패키지. 진단 페이지(정찰/취약점 스캐너 모달)에 올라있는 도구 전체를
그대로 담았다 -- recon-toolkit/safe-http-audit/xss-reflected-scanner/
xss-stored-scanner/jwt-analyzer/crypto-identifier/burp-history-tool 7개는
pip install 같은 패키지 설치 없이 바로 실행 가능(전부 Python 표준
라이브러리만 사용). client-route-scout 는 Python 스크립트가 아니라 브라우저
DevTools 콘솔에 붙여넣는 스크립트라 사용법이 다르다(해당 폴더의
MANUAL_KR.txt 참고).

recon-toolkit/recon_toolkit.py 는 워드리스트(SecLists/PayloadsAllTheThings
서브셋)가 파일 안에 압축 내장돼 있다 -- 별도 폴더 필요 없이 이 파일 하나만
있으면 바로 실행된다. 루트 확인(robots.txt/sitemap.xml 등으로 실제 루트
경로 확정) -> 기본/백업 파일 탐색 -> 경로순회(Traversal)/LFI 퍼징 -> 링크
크롤링 순서로 동작하며, 대상을 여러 개 동시에 돌릴 수도 있다.

각 폴더의 MANUAL_KR.txt가 원래 이름 "설명서.txt"다 -- zip 포맷은 한글
파일명을 옛날 방식(UTF-8 플래그 없이)으로 저장하면 Windows 압축 해제
프로그램에서 깨진 문자로 나오는 경우가 있어서, 이 zip 안에서만 영문
이름으로 바꿔둠. 내용은 그대로 한글 설명서다.

폴더 구성
--------
  recon-toolkit/recon_toolkit.py                 <- 루트확인/기본파일/경로순회/크롤링 올인원
  safe-http-audit/safe_http_audit.py (+ safe_rule_bundle.py, safe_http_checks/)
  xss-reflected-scanner/xss_reflected_scanner.py <- Reflected XSS 스캐너
  xss-stored-scanner/xss_stored_scanner.py       <- Stored XSS 스캐너
  jwt-analyzer/jwt_analyzer.py                   <- JWT(JWS/JWE) 구조 분석기
  crypto-identifier/crypto_identifier.py         <- 해시/인코딩 식별기
  burp-history-tool/burp_history_to_wordlist.py  <- 네트워크 요청 없음, 어디서나 실행 가능
  client-route-scout/client-route-scout-console-script.txt  <- 브라우저 콘솔에 붙여넣는 스크립트(MANUAL_KR.txt 참고)

실행 방법
--------
각 폴더 안에서(client-route-scout 제외):
  python recon_toolkit.py                    (인자 없이 실행 -> 한글 질문 순서대로)
  python safe_http_audit.py
  python xss_reflected_scanner.py
  python xss_stored_scanner.py
  python jwt_analyzer.py
  python crypto_identifier.py
  python burp_history_to_wordlist.py
자세한 옵션은 각 폴더의 MANUAL_KR.txt 참고. recon_toolkit.py는 --help로도
전체 옵션 확인 가능(설명 문구는 한글).

출처 / 라이선스: recon_toolkit.py에 내장된 워드리스트는 SecLists·
PayloadsAllTheThings(둘 다 MIT 라이선스)에서 가져온 서브셋이다.
  https://github.com/danielmiessler/SecLists
  https://github.com/swisskyrepo/PayloadsAllTheThings

주의
----
소유하거나 명시적으로 허가받은 대상에서만 사용할 것.
